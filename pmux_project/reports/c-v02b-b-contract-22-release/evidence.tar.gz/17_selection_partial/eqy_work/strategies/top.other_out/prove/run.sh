STATUS=ERROR
sby -f top.other_out.sby > /dev/null && STATUS=$(awk '{print $1}' top.other_out/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'top.other_out' using strategy 'prove'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'top.other_out' using strategy 'prove': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'top.other_out' using strategy 'prove': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'top.other_out' using strategy 'prove': timeout"
    ;;
    *)
        cat top.other_out/ERROR 2> /dev/null
        echo "Execution of strategy 'prove' on partition 'top.other_out' encountered an error."
        echo "More details can be found in '/home/yuewen/work/pmux-yosys-c-v02b-b-contract/pmux_project/reports/c-v02b-b-contract-22-release/17_selection_partial/eqy_work/strategies/top.other_out/prove/top.other_out/logfile.txt'."
        exit 1
    ;;
esac
exit 0

