STATUS=ERROR
sby -f test1.i0.sby > /dev/null && STATUS=$(awk '{print $1}' test1.i0/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'test1.i0' using strategy 'pdr'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'test1.i0' using strategy 'pdr': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'test1.i0' using strategy 'pdr': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'test1.i0' using strategy 'pdr': timeout"
    ;;
    *)
        cat test1.i0/ERROR 2> /dev/null
        echo "Execution of strategy 'pdr' on partition 'test1.i0' encountered an error."
        echo "More details can be found in '/home/yuewen/work/pmux-yosys-c-real/pmux_project/reports/c-official-b-audited/case1/eqy_whole/strategies/test1.i0/pdr/test1.i0/logfile.txt'."
        exit 1
    ;;
esac
exit 0

