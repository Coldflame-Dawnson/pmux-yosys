.DEFAULT_GOAL := all

strategies/test4.only_5b/sat/status:
	@echo "Running strategy 'sat' on 'test4.only_5b'.."
	@bash -c "cd strategies/test4.only_5b/sat; source run.sh"

strategies/test4.dataout/sat/status:
	@echo "Running strategy 'sat' on 'test4.dataout'.."
	@bash -c "cd strategies/test4.dataout/sat; source run.sh"

strategies/test4.datain_5bis7/sat/status:
	@echo "Running strategy 'sat' on 'test4.datain_5bis7'.."
	@bash -c "cd strategies/test4.datain_5bis7/sat; source run.sh"

strategies/test4.data_dp/sat/status:
	@echo "Running strategy 'sat' on 'test4.data_dp'.."
	@bash -c "cd strategies/test4.data_dp/sat; source run.sh"

strategies/test4.data_dn/sat/status:
	@echo "Running strategy 'sat' on 'test4.data_dn'.."
	@bash -c "cd strategies/test4.data_dn/sat; source run.sh"

.PHONY: all summary
all: strategies/test4.data_dn/sat/status strategies/test4.data_dp/sat/status strategies/test4.datain_5bis7/sat/status strategies/test4.dataout/sat/status strategies/test4.only_5b/sat/status
	$(MAKE) -f strategies.mk summary
summary:
	@rc=0 ; \
	while read f; do \
		p=$${f#strategies/} ; p=$${p%/*/status} ; \
		if grep -q "PASS" $$f ; then \
			echo "* Successfully proved equivalence of partition $$p" ; \
		else \
			echo "* Failed to prove equivalence of partition $$p" ; rc=1 ; \
		fi ; \
	done < summary_targets.list ; \
	if [ "$$rc" -eq 0 ] ; then \
		echo "* Successfully proved designs equivalent" ; \
	fi
