.DEFAULT_GOAL := all

strategies/test1.state/sat/status:
	@echo "Running strategy 'sat' on 'test1.state'.."
	@bash -c "cd strategies/test1.state/sat; source run.sh"

strategies/test1.q7/sat/status:
	@echo "Running strategy 'sat' on 'test1.q7'.."
	@bash -c "cd strategies/test1.q7/sat; source run.sh"

strategies/test1.q6/sat/status:
	@echo "Running strategy 'sat' on 'test1.q6'.."
	@bash -c "cd strategies/test1.q6/sat; source run.sh"

strategies/test1.q5/sat/status:
	@echo "Running strategy 'sat' on 'test1.q5'.."
	@bash -c "cd strategies/test1.q5/sat; source run.sh"

strategies/test1.q4/sat/status:
	@echo "Running strategy 'sat' on 'test1.q4'.."
	@bash -c "cd strategies/test1.q4/sat; source run.sh"

strategies/test1.q3/sat/status:
	@echo "Running strategy 'sat' on 'test1.q3'.."
	@bash -c "cd strategies/test1.q3/sat; source run.sh"

strategies/test1.q2/sat/status:
	@echo "Running strategy 'sat' on 'test1.q2'.."
	@bash -c "cd strategies/test1.q2/sat; source run.sh"

strategies/test1.q1/sat/status:
	@echo "Running strategy 'sat' on 'test1.q1'.."
	@bash -c "cd strategies/test1.q1/sat; source run.sh"

strategies/test1.q0/sat/status:
	@echo "Running strategy 'sat' on 'test1.q0'.."
	@bash -c "cd strategies/test1.q0/sat; source run.sh"

strategies/test1.por6_out/sat/status:
	@echo "Running strategy 'sat' on 'test1.por6_out'.."
	@bash -c "cd strategies/test1.por6_out/sat; source run.sh"

strategies/test1.inter0009_out.11/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.11'.."
	@bash -c "cd strategies/test1.inter0009_out.11/sat; source run.sh"

strategies/test1.inter0009_out.10/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.10'.."
	@bash -c "cd strategies/test1.inter0009_out.10/sat; source run.sh"

strategies/test1.inter0009_out.9/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.9'.."
	@bash -c "cd strategies/test1.inter0009_out.9/sat; source run.sh"

strategies/test1.inter0009_out.8/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.8'.."
	@bash -c "cd strategies/test1.inter0009_out.8/sat; source run.sh"

strategies/test1.inter0009_out.7/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.7'.."
	@bash -c "cd strategies/test1.inter0009_out.7/sat; source run.sh"

strategies/test1.inter0009_out.6/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.6'.."
	@bash -c "cd strategies/test1.inter0009_out.6/sat; source run.sh"

strategies/test1.inter0009_out.5/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.5'.."
	@bash -c "cd strategies/test1.inter0009_out.5/sat; source run.sh"

strategies/test1.inter0009_out.4/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.4'.."
	@bash -c "cd strategies/test1.inter0009_out.4/sat; source run.sh"

strategies/test1.inter0009_out.3/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.3'.."
	@bash -c "cd strategies/test1.inter0009_out.3/sat; source run.sh"

strategies/test1.inter0009_out.2/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.2'.."
	@bash -c "cd strategies/test1.inter0009_out.2/sat; source run.sh"

strategies/test1.inter0009_out.1/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.1'.."
	@bash -c "cd strategies/test1.inter0009_out.1/sat; source run.sh"

strategies/test1.inter0009_out.0/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0009_out.0'.."
	@bash -c "cd strategies/test1.inter0009_out.0/sat; source run.sh"

strategies/test1.inter0008_out.11/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.11'.."
	@bash -c "cd strategies/test1.inter0008_out.11/sat; source run.sh"

strategies/test1.inter0008_out.10/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.10'.."
	@bash -c "cd strategies/test1.inter0008_out.10/sat; source run.sh"

strategies/test1.inter0008_out.9/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.9'.."
	@bash -c "cd strategies/test1.inter0008_out.9/sat; source run.sh"

strategies/test1.inter0008_out.8/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.8'.."
	@bash -c "cd strategies/test1.inter0008_out.8/sat; source run.sh"

strategies/test1.inter0008_out.7/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.7'.."
	@bash -c "cd strategies/test1.inter0008_out.7/sat; source run.sh"

strategies/test1.inter0008_out.6/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.6'.."
	@bash -c "cd strategies/test1.inter0008_out.6/sat; source run.sh"

strategies/test1.inter0008_out.5/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.5'.."
	@bash -c "cd strategies/test1.inter0008_out.5/sat; source run.sh"

strategies/test1.inter0008_out.4/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.4'.."
	@bash -c "cd strategies/test1.inter0008_out.4/sat; source run.sh"

strategies/test1.inter0008_out.3/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.3'.."
	@bash -c "cd strategies/test1.inter0008_out.3/sat; source run.sh"

strategies/test1.inter0008_out.2/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.2'.."
	@bash -c "cd strategies/test1.inter0008_out.2/sat; source run.sh"

strategies/test1.inter0008_out.1/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.1'.."
	@bash -c "cd strategies/test1.inter0008_out.1/sat; source run.sh"

strategies/test1.inter0008_out.0/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0008_out.0'.."
	@bash -c "cd strategies/test1.inter0008_out.0/sat; source run.sh"

strategies/test1.inter0007_out/sat/status:
	@echo "Running strategy 'sat' on 'test1.inter0007_out'.."
	@bash -c "cd strategies/test1.inter0007_out/sat; source run.sh"

strategies/test1.i7/sat/status:
	@echo "Running strategy 'sat' on 'test1.i7'.."
	@bash -c "cd strategies/test1.i7/sat; source run.sh"

strategies/test1.i6/sat/status:
	@echo "Running strategy 'sat' on 'test1.i6'.."
	@bash -c "cd strategies/test1.i6/sat; source run.sh"

strategies/test1.i5/sat/status:
	@echo "Running strategy 'sat' on 'test1.i5'.."
	@bash -c "cd strategies/test1.i5/sat; source run.sh"

strategies/test1.i4/sat/status:
	@echo "Running strategy 'sat' on 'test1.i4'.."
	@bash -c "cd strategies/test1.i4/sat; source run.sh"

strategies/test1.i3/sat/status:
	@echo "Running strategy 'sat' on 'test1.i3'.."
	@bash -c "cd strategies/test1.i3/sat; source run.sh"

strategies/test1.i2/sat/status:
	@echo "Running strategy 'sat' on 'test1.i2'.."
	@bash -c "cd strategies/test1.i2/sat; source run.sh"

strategies/test1.i1/sat/status:
	@echo "Running strategy 'sat' on 'test1.i1'.."
	@bash -c "cd strategies/test1.i1/sat; source run.sh"

strategies/test1.i0/sat/status:
	@echo "Running strategy 'sat' on 'test1.i0'.."
	@bash -c "cd strategies/test1.i0/sat; source run.sh"

.PHONY: all summary
all: strategies/test1.i0/sat/status strategies/test1.i1/sat/status strategies/test1.i2/sat/status strategies/test1.i3/sat/status strategies/test1.i4/sat/status strategies/test1.i5/sat/status strategies/test1.i6/sat/status strategies/test1.i7/sat/status strategies/test1.inter0007_out/sat/status strategies/test1.inter0008_out.0/sat/status strategies/test1.inter0008_out.1/sat/status strategies/test1.inter0008_out.10/sat/status strategies/test1.inter0008_out.11/sat/status strategies/test1.inter0008_out.2/sat/status strategies/test1.inter0008_out.3/sat/status strategies/test1.inter0008_out.4/sat/status strategies/test1.inter0008_out.5/sat/status strategies/test1.inter0008_out.6/sat/status strategies/test1.inter0008_out.7/sat/status strategies/test1.inter0008_out.8/sat/status strategies/test1.inter0008_out.9/sat/status strategies/test1.inter0009_out.0/sat/status strategies/test1.inter0009_out.1/sat/status strategies/test1.inter0009_out.10/sat/status strategies/test1.inter0009_out.11/sat/status strategies/test1.inter0009_out.2/sat/status strategies/test1.inter0009_out.3/sat/status strategies/test1.inter0009_out.4/sat/status strategies/test1.inter0009_out.5/sat/status strategies/test1.inter0009_out.6/sat/status strategies/test1.inter0009_out.7/sat/status strategies/test1.inter0009_out.8/sat/status strategies/test1.inter0009_out.9/sat/status strategies/test1.por6_out/sat/status strategies/test1.q0/sat/status strategies/test1.q1/sat/status strategies/test1.q2/sat/status strategies/test1.q3/sat/status strategies/test1.q4/sat/status strategies/test1.q5/sat/status strategies/test1.q6/sat/status strategies/test1.q7/sat/status strategies/test1.state/sat/status
	$(MAKE) -f strategies.mk summary
summary:
	@rc=0 ; \
	while read f; do \
		p=$${f#strategies/} ; p=$${p%/*/status} ; \
		if grep -q "PASS" $$f ; then \
			echo "* Successfully proved equivalence of partition $$p" ; \
		else \
			echo "* Failed to prove equivalence of partition $$p" ; rc=1 ; \
		fi ; \
	done < summary_targets.list ; \
	if [ "$$rc" -eq 0 ] ; then \
		echo "* Successfully proved designs equivalent" ; \
	fi
