yosys -ql run.log run.ys
if grep "SAT temporal induction proof finished - model found for base case: FAIL!" run.log > /dev/null ; then
	echo FAIL > status
	echo "Could not prove equivalence of partition 'test1.i0' using strategy 'sat': partitions not equivalent"
elif grep "Reached maximum number of time steps -> proof failed." run.log > /dev/null ; then
	echo UNKNOWN > status
	echo "Could not prove equivalence of partition 'test1.i0' using strategy 'sat': equivalence unknown"
elif grep "Interrupted SAT solver: TIMEOUT!" run.log > /dev/null ; then
	echo UNKNOWN > status
	echo "Could not prove equivalence of partition 'test1.i0' using strategy 'sat': timeout"
elif grep "Induction step proven: SUCCESS!" run.log > /dev/null ; then
	echo PASS > status
	echo "Proved equivalence of partition 'test1.i0' using strategy 'sat'"
else
	echo ERROR > status
	echo "Execution of strategy 'sat' on partition 'test1.i0' encountered an error.
Details can be found in '/home/dawnson/work/pmux-yosys-a-case12-audit/pmux_project/reports/a-case12-width-reaudit-4c43ab9/unified-official/case1/eqy_work/strategies/test1.i0/sat/run.log'."
	exit 1
fi
exit 0

