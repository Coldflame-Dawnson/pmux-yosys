module miter (
  input  [  7:0] \__pi_q ,
  input  [  7:0] \__pi_x ,
`ifdef DIRECT_CROSS_POINTS
`else
`endif
  output [  7:0] \__po_out__gold ,
  output [  7:0] \__po_shared__gold ,
  output [  7:0] \__po_out__gate ,
  output [  7:0] \__po_shared__gate
);
  \gold.top gold (
    .\__pi_q (\__pi_q ),
    .\__pi_x (\__pi_x ),
`ifdef DIRECT_CROSS_POINTS
`else
`endif
    .\__po_out (\__po_out__gold ),
    .\__po_shared (\__po_shared__gold )
  );
  \gate.top gate (
    .\__pi_q (\__pi_q ),
    .\__pi_x (\__pi_x ),
`ifdef DIRECT_CROSS_POINTS
`else
`endif
    .\__po_out (\__po_out__gate ),
    .\__po_shared (\__po_shared__gate )
  );
`ifdef ASSUME_DEFINED_INPUTS
  miter_def_prop #(8, "assume") \__pi_q__assume (\__pi_q );
  miter_def_prop #(8, "assume") \__pi_x__assume (\__pi_x );
`endif
`ifndef DIRECT_CROSS_POINTS
`endif
`ifdef CHECK_MATCH_POINTS
`endif
`ifdef CHECK_OUTPUTS
  miter_cmp_prop #(8, "assert") \__po_out__assert (\__po_out__gold , \__po_out__gate );
  miter_cmp_prop #(8, "assert") \__po_shared__assert (\__po_shared__gold , \__po_shared__gate );
`endif
`ifdef COVER_DEF_CROSS_POINTS
  `ifdef DIRECT_CROSS_POINTS
  `else
  `endif
`endif
`ifdef COVER_DEF_GOLD_MATCH_POINTS
`endif
`ifdef COVER_DEF_GATE_MATCH_POINTS
`endif
`ifdef COVER_DEF_GOLD_OUTPUTS
  miter_def_prop #(8, "cover") \__po_out__gold_cover (\__po_out__gold );
  miter_def_prop #(8, "cover") \__po_shared__gold_cover (\__po_shared__gold );
`endif
`ifdef COVER_DEF_GATE_OUTPUTS
  miter_def_prop #(8, "cover") \__po_out__gate_cover (\__po_out__gate );
  miter_def_prop #(8, "cover") \__po_shared__gate_cover (\__po_shared__gate );
`endif
endmodule
module miter_cmp_prop #(parameter WIDTH=1, parameter TYPE="assert") (input [WIDTH-1:0] in_gold, in_gate);
  reg okay;
  integer i;
  always @* begin
    okay = 1;
    for (i = 0; i < WIDTH; i = i+1)
      okay = okay && (in_gold[i] === 1'bx || in_gold[i] === in_gate[i]);
  end
  generate
    if (TYPE == "assert") always @* assert(okay);
    if (TYPE == "assume") always @* assume(okay);
    if (TYPE == "cover")  always @* cover(okay);
  endgenerate
endmodule
module miter_def_prop #(parameter WIDTH=1, parameter TYPE="assert") (input [WIDTH-1:0] in);
  wire okay = ^in !== 1'bx;
  generate
    if (TYPE == "assert") always @* assert(okay);
    if (TYPE == "assume") always @* assume(okay);
    if (TYPE == "cover")  always @* cover(okay);
  endgenerate
endmodule
module \gold.top (
  input  [  7:0] \__pi_q ,
  input  [  7:0] \__pi_x ,
  output [  7:0] \__po_out ,
  output [  7:0] \__po_shared
);
endmodule
module \gate.top (
  input  [  7:0] \__pi_q ,
  input  [  7:0] \__pi_x ,
  output [  7:0] \__po_out ,
  output [  7:0] \__po_shared
);
endmodule
