# M1 微型回归 (external)

结构：PASS；EQY：PASS；LUT 收益：NOT_RUN。

Fixture replay 仅验证测试框架，不能视作真实证明引擎通过。

| Case | 结构 | check | EQY | 语义 |
|---|---|---|---|---|
| 01_mux_a | PASS | PASS | PASS | PASS |
| 02_mux_b | PASS | PASS | PASS | PASS |
| 03_pmux_a | PASS | PASS | PASS | PASS |
| 04_pmux_bi | PASS | PASS | PASS | PASS |
| 05_eq_reverse | PASS | PASS | PASS | PASS |
| 06_ne_zero_reverse | PASS | PASS | PASS | PASS |
| 07_partial_bit | PASS | PASS | PASS | PASS |
| 08_shared_source | PASS | PASS | PASS | PASS |
| 09_overlap_pmux | PASS | PASS | PASS | PASS |
| 10_xz_untouched | PASS | PASS | PASS | PASS |
| 11_ambiguous_compare | PASS | PASS | PASS | PASS |
| 12_unsupported_cell | PASS | PASS | PASS | PASS |
| 13_fact_conflict | PASS | PASS | PASS | PASS |
| 14a_budget_cells | PASS | PASS | PASS | PASS |
| 14b_budget_bits | PASS | PASS | PASS | PASS |
| 14c_budget_events | PASS | PASS | PASS | PASS |
| 15_multi_branch_merge | PASS | PASS | PASS | PASS |
| 16_no_opportunity | PASS | PASS | PASS | PASS |
| 17_case3_seven_bits | PASS | PASS | PASS | PASS |
