STATUS=ERROR
sby -f top.out.sby > /dev/null && STATUS=$(awk '{print $1}' top.out/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'top.out' using strategy 'prove'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'top.out' using strategy 'prove': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'top.out' using strategy 'prove': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'top.out' using strategy 'prove': timeout"
    ;;
    *)
        cat top.out/ERROR 2> /dev/null
        echo "Execution of strategy 'prove' on partition 'top.out' encountered an error."
        echo "More details can be found in '/home/james/work/pmux-yosys-b-case34-production/pmux_project/reports/b-case12-default-micro19/15_multi_branch_merge/eqy_work/strategies/top.out/prove/top.out/logfile.txt'."
        exit 1
    ;;
esac
exit 0

