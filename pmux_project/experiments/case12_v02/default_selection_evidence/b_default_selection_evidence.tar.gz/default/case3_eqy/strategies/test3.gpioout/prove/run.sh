STATUS=ERROR
sby -f test3.gpioout.sby > /dev/null && STATUS=$(awk '{print $1}' test3.gpioout/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'test3.gpioout' using strategy 'prove'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'test3.gpioout' using strategy 'prove': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'test3.gpioout' using strategy 'prove': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'test3.gpioout' using strategy 'prove': timeout"
    ;;
    *)
        cat test3.gpioout/ERROR 2> /dev/null
        echo "Execution of strategy 'prove' on partition 'test3.gpioout' encountered an error."
        echo "More details can be found in '/home/james/work/pmux-yosys-b-case34-production/pmux_project/reports/b-case12-default-selection-final-delivery/case3_eqy/strategies/test3.gpioout/prove/test3.gpioout/logfile.txt'."
        exit 1
    ;;
esac
exit 0

