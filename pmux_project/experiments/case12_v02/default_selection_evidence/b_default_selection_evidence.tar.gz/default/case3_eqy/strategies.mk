.DEFAULT_GOAL := all

strategies/test3.gpioout/sat/status:
	@echo "Running strategy 'sat' on 'test3.gpioout'.."
	@bash -c "cd strategies/test3.gpioout/sat; source run.sh"

strategies/test3.gpioout/prove/status: strategies/test3.gpioout/sat/status
	@if grep PASS $^ >/dev/null ; then \
		echo "PASS (cached)" > $@; \
	elif grep FAIL $^ >/dev/null ; then \
		echo "FAIL (cached)" > $@; \
	else \
		echo "Running strategy 'prove' on 'test3.gpioout'.."; \
		bash -c "cd strategies/test3.gpioout/prove; source run.sh"; \
	fi

.PHONY: all summary
all: strategies/test3.gpioout/prove/status
	$(MAKE) -f strategies.mk summary
summary:
	@rc=0 ; \
	while read f; do \
		p=$${f#strategies/} ; p=$${p%/*/status} ; \
		if grep -q "PASS" $$f ; then \
			echo "* Successfully proved equivalence of partition $$p" ; \
		else \
			echo "* Failed to prove equivalence of partition $$p" ; rc=1 ; \
		fi ; \
	done < summary_targets.list ; \
	if [ "$$rc" -eq 0 ] ; then \
		echo "* Successfully proved designs equivalent" ; \
	fi
