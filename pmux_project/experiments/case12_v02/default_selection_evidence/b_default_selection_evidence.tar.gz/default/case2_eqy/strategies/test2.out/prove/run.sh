STATUS=ERROR
sby -f test2.out.sby > /dev/null && STATUS=$(awk '{print $1}' test2.out/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'test2.out' using strategy 'prove'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'test2.out' using strategy 'prove': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'test2.out' using strategy 'prove': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'test2.out' using strategy 'prove': timeout"
    ;;
    *)
        cat test2.out/ERROR 2> /dev/null
        echo "Execution of strategy 'prove' on partition 'test2.out' encountered an error."
        echo "More details can be found in '/home/james/work/pmux-yosys-b-case34-production/pmux_project/reports/b-case12-default-selection-final-delivery/case2_eqy/strategies/test2.out/prove/test2.out/logfile.txt'."
        exit 1
    ;;
esac
exit 0

