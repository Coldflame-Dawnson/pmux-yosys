STATUS=ERROR
sby -f test1.i0.sby > /dev/null && STATUS=$(awk '{print $1}' test1.i0/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'test1.i0' using strategy 'prove'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'test1.i0' using strategy 'prove': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'test1.i0' using strategy 'prove': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'test1.i0' using strategy 'prove': timeout"
    ;;
    *)
        cat test1.i0/ERROR 2> /dev/null
        echo "Execution of strategy 'prove' on partition 'test1.i0' encountered an error."
        echo "More details can be found in '/home/james/work/pmux-yosys-b-case34-production/pmux_project/reports/b-case12-default-selection-final-delivery/case1_eqy/strategies/test1.i0/prove/test1.i0/logfile.txt'."
        exit 1
    ;;
esac
exit 0

