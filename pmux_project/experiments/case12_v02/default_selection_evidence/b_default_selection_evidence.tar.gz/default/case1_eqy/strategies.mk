.DEFAULT_GOAL := all

strategies/test1.i0/sat/status:
	@echo "Running strategy 'sat' on 'test1.i0'.."
	@bash -c "cd strategies/test1.i0/sat; source run.sh"

strategies/test1.i0/prove/status: strategies/test1.i0/sat/status
	@if grep PASS $^ >/dev/null ; then \
		echo "PASS (cached)" > $@; \
	elif grep FAIL $^ >/dev/null ; then \
		echo "FAIL (cached)" > $@; \
	else \
		echo "Running strategy 'prove' on 'test1.i0'.."; \
		bash -c "cd strategies/test1.i0/prove; source run.sh"; \
	fi

.PHONY: all summary
all: strategies/test1.i0/prove/status
	$(MAKE) -f strategies.mk summary
summary:
	@rc=0 ; \
	while read f; do \
		p=$${f#strategies/} ; p=$${p%/*/status} ; \
		if grep -q "PASS" $$f ; then \
			echo "* Successfully proved equivalence of partition $$p" ; \
		else \
			echo "* Failed to prove equivalence of partition $$p" ; rc=1 ; \
		fi ; \
	done < summary_targets.list ; \
	if [ "$$rc" -eq 0 ] ; then \
		echo "* Successfully proved designs equivalent" ; \
	fi
