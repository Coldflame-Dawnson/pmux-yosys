module cycloneiv_lcell_comb(dataa,datab,datac,datad,cin,combout);
parameter [15:0] lut_mask = 16'hffff;
parameter sum_lutc_input = "datac";
input dataa,datab,datac,datad,cin;
output combout;
assign combout = lut_mask[{datad,datac,datab,dataa}];
endmodule
