STATUS=ERROR
sby -f test4.data_dn.sby > /dev/null && STATUS=$(awk '{print $1}' test4.data_dn/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'test4.data_dn' using strategy 'prove'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'test4.data_dn' using strategy 'prove': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'test4.data_dn' using strategy 'prove': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'test4.data_dn' using strategy 'prove': timeout"
    ;;
    *)
        cat test4.data_dn/ERROR 2> /dev/null
        echo "Execution of strategy 'prove' on partition 'test4.data_dn' encountered an error."
        echo "More details can be found in '/home/james/work/pmux-yosys-b-case34-production/pmux_project/reports/b-case12-default-selection-final-delivery/case4_eqy/strategies/test4.data_dn/prove/test4.data_dn/logfile.txt'."
        exit 1
    ;;
esac
exit 0

